﻿namespace Glory
{
	enum LRNodeType
	{
		Initial =-1,
		Shift ,
		Reduce ,
		Accept ,
		Error ,
		EndDocument
	}

}
