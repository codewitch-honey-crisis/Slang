﻿// namespace will be replaced
namespace T_NAMESPACE
{
	// type name will be replaced
	class T_TYPE
	{
		// init value will be replaced
		public static int[] Primes = null;

	}
}
