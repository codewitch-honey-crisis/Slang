﻿using System;

namespace scratch
{
	class Resolver
	{
		void Main()
		{
			var s = "foo";
			Console.WriteLine(s);
		}
	}
}
