﻿using System;

namespace scratch
{
	/// <summary>
	/// Test summary
	/// </summary>
	class Resolver
	{
		void Main()
		{
			// foo
			var s = "foo";
			Console.WriteLine(s);
		}
	}
}
