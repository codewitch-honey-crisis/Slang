﻿using System.Collections.Generic;

namespace Parsley
{

	partial class Parser
	{
		internal const int ErrorSymbol = -1;
		internal const int EosSymbol = -2;
		
		
	}
}
