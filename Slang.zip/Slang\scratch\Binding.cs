﻿using System;

namespace scratch
{
	class Binding
	{
		public void Test(string text)
		{
			Console.WriteLine(text);
		}
		public void Test(int value)
		{
			Console.WriteLine(value);
		}
	}
}
